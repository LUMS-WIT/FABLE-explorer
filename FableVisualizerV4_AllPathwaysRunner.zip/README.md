# FableVisualizerV4

FableVisualizerV4 is a lightweight toolkit to run **all FABLE pathways** and explore results in a Streamlit dashboard.

## What's Included
- `FableVisualizerV4_AllPathwaysRunner.ipynb` — notebook runner (Excel automation + exports)
- `FableVisualizerV4_AllPathwaysRunner.py` — runner module used by notebook/launcher
- `FableVisualizerV4_Dashboard.py` — Streamlit dashboard for viewing exported results
- `FableVisualizerV4_Launcher.py` — Tkinter launcher (run exports + dashboard)
- `Launch_FableVisualizerV4_Dashboard.bat` — dashboard only (no recalculation)
- `Launch_FableVisualizerV4_Launcher.bat` — exports + dashboard

## Requirements
- Windows + Microsoft Excel installed
- Python packages: `pandas`, `openpyxl`, `pywin32`, `streamlit`, `plotly`

## Quick Start (Dashboard Only)
Double-click:
```
Launch_FableVisualizerV4_Dashboard.bat
```

This opens the dashboard. In the sidebar, point it at an existing `exports\all_pathways_run_*` folder.

## Run Exports + Dashboard
Double-click:
```
Launch_FableVisualizerV4_Launcher.bat
```

This opens the launcher, lets you select a workbook and export folder, runs all pathways, and then opens the dashboard.

## Notebook Usage
Open and run:
```
FableVisualizerV4_AllPathwaysRunner.ipynb
```

## Outputs
Exports are saved to:
```
<workbook folder>\exports\all_pathways_run_YYYYMMDD_HHMMSS
```

## Troubleshooting
- If a BAT file does nothing, make sure `streamlit` is installed and the `.py` files are in the same folder as the BAT.
- If the dashboard fails to open automatically, run from PowerShell:
```
python -m streamlit run FableVisualizerV4_Dashboard.py
```

