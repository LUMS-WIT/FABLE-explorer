@echo off
setlocal
set "PYEXE=C:\Users\AhmedSaeed\AppData\Local\Programs\Python\Python312\pythonw.exe"
set "SCRIPT=%~dp0FableVisualizerV4_Dashboard.py"

if not exist "%SCRIPT%" (
  echo Missing: %SCRIPT%
  pause
  exit /b 1
)

if exist "%PYEXE%" (
  start "" "%PYEXE%" -m streamlit run "%SCRIPT%"
) else (
  start "" python -m streamlit run "%SCRIPT%"
)
endlocal
